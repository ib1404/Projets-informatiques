<?php
session_start();
$con = mysqli_connect("localhost","root","","config2");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <!-- lien de la blibliotèque d'icon fontawesome -->
    <title>Ecohome</title>


</head>

<body>

    <script src="event.js"></script>

    <header>
        <div id="top" class="top">
            <a href="index.php" class="logo"><img src="https://i.goopics.net/kdv184.png" class="ecohome"></a>
            <div class="profil">
                <a href="profil.php"><?php echo ucwords($_SESSION['username']); ?></a>
                <a href="profil.php"><img src="https://i.goopics.net/p5sdhc.png" class="profil_picture"></a>
                <!--<li> <div class="notification">
                    <a class="notification-number" href="">3</a>
                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                    <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
                    </svg>
                </div></li>-->
            </div>
        </div>
    
        <nav>
            <li id="underhead" class="underhead">
                <a href="index.php">Accueil</a>
                <a href="classement.php">Classement</a>
                <a href="glc.php">Gérer les capteurs</a>
                <a href="notification.php">Notifications</a>
                <a href="forum.php" style="color:#00FF00;">Forum</a>
                <a href="parametre.php">Paramètres</a>
            </li>
        </nav>

    </header>

    <section >
            

            <div class="global">
                <p class="FAQ">Foire Aux Questions :</p>    
                <div>
                    <p class="Question">Comment résoudre un problème de connexion lié à un capteur ?</p>
                    <p class="Réponse">Pour résoudre le problème, il suffit de supprimer le capteur puis de le rajouter.</p>
                </div>
                <div class="global div">
                    <p class="Question">Comment modifier les capteurs instalés ?</p>
                    <p class="Réponse">Pour modifier les capteurs instalés il suffit de cliquer sur le bouton modifier à côté du nom du capteur, et modifier le nom du capteur puis cliquer sur le bouton "valider" ou bien supprimer le capteur s'il n'est plus utile.</p>
                </div>
                <div class="global div">
                    <p class="Question">Comment modifier son pseudo ?</p>
                    <p class="Réponse">Pour modifier son pseudo, il faut aller dans "mon profil" et cliquer sur "modifier mes informations", puis changer son pseudo dans la barre d'entré, une fois modifié, cliquer sur "valider".</p>
                </div>
                <div>
                    <p class="Question">Comment obtenir des points pour le score écologique ?</p>
                    <p class="Réponse">Pour obtenir des points pour le score écologique, il faut se connecter chaque jour à son compte ecohome pour obtenir les points de connexions et effectuer les tâches demandés pour diminuer sa consommation énergétique et donc contribuer à l'écologie et obtenir des points.</p>
                </div>
                <div class="global div">
                    <p class="Question">Comment joindre des utilisateurs de la région ?</p>
                    <p class="Réponse">Il faut effectuer une recherche d'utilisateur par critère, en sélectionnant la région que l'on souhaite dans le critère "région" et en sélectionnant "tout" dans le critère "utilisateur". Ensuite il faut sélectionner l'utilisateur à qui l'on souhaite joindre et cliquer sur envoyer un message.</p>
                </div>
                <div>
                    <p class="Question">Comment supprimer son compte Ecohome ?</p>
                    <p class="Réponse">Il faut se rendre sur la rubrique "mon profil" puis cliquer sur "paramètre du compte" puis sur "supprimer mon compte" et confirmer sa suppression.</p>
                    
                </div>
                
            </div>
            
    </section>


</body>

</html>