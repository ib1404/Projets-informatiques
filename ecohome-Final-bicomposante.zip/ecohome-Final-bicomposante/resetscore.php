<?php
    ob_start();
    session_start();  
    // Enter your host name, database username, password, and database name.
    // If you have not set database password on localhost then set empty.
    $con = mysqli_connect("localhost","root","","config2");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }



	

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>classement</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
</head>
<body>
<header>
        <div id="top" class="top">
            <a href="index.php" class="logo"><img src="https://i.goopics.net/kdv184.png" class="ecohome"></a>
            <div class="profil">
                <a href="profil.php"><?php echo ucwords($_SESSION['username']); ?></a>
                <a href="profil.php"><img src="https://i.goopics.net/p5sdhc.png" class="profil_picture"></a>
                <!--<li> <div class="notification">
                    <a class="notification-number" href="">3</a>
                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                    <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
                    </svg>
                </div></li>-->
            </div>
        </div>
    
        <nav>
            <li id="underhead" class="underhead">
                <a href="index.php">Accueil</a>
                <a href="classement.php" style="color:#00FF00;">Classement</a>
                <a href="glc.php">Gérer les capteurs</a>
                <a href="notification.php">Notifications</a>
                <a href="forum.php">Forum</a>
                <a href="parametre.php">Paramètres</a>
            </li>
        </nav>

    </header>
<?php
// define variables and set to empty values
$name = $code = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = test_input($_POST["name"]);
  $code = test_input($_POST["code"]);

}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<div  id="inscrip">

    <div class="img_pasdeco">
        <img src="https://i.goopics.net/5loehf.jpg" height="100%" width="100%" alt>
    </div>
  
  <form class="form" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <h1 align="center">RESET SCORE</h1>
    <br>
    <div class="barre-de-séparation"></div>
    <br><br>
    <div class="corp">  
      <div class="groupe">Name: <input  type="text" class="login-button" name="name">
          <br><br>
      </div>
      <div class="groupe">Code: <input type="text"  class="login-button" name="code">
        <br><br>
      </div>
      <div class="pied">
        <input type="submit"  class="login-button" name="submit" value="RESET">
         
        
      </div>
        <br><br> 
      <div class="pied_left">
        <a href="classement.php"> <i class="fas fa-undo-alt"></i> </a>
        <br><br>  
      </div>  
      
</div>
</form>
</div>
<?php
if($code = '1234' AND $name= '1234' )
{
	
	
	$resetscore1 = "UPDATE score SET score = 0";
	$resetscore = mysqli_query($con, $resetscore1)or (mysqli_error()) ;
}
	
			
	

?>
</body>
</html>