<?php
session_start();
$con = mysqli_connect("localhost","root","","config2");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <!-- lien de la blibliotèque d'icon fontawesome -->
    <title>Ecohome</title>


</head>

<body>

    <script src="event.js"></script>

    <header>
        <div id="top" class="top">
            <a href="index.php" class="logo"><img src="https://i.goopics.net/kdv184.png" class="ecohome"></a>
            <div class="profil">
                <a href="parametre.php" style="color:#00FF00;"><?php echo ucwords($_SESSION['username']); ?></a>
                <a href="parametre.php"><img src="https://i.goopics.net/p5sdhc.png" class="profil_picture"></a>
                <!--<li> <div class="notification">
                    <a class="notification-number" href="">3</a>
                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                    <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
                    </svg>
                </div></li>-->
            </div>
        </div>
    
        <nav>
            <li id="underhead" class="underhead">
                <a href="index.php">Accueil</a>
                <a href="classement.php">Classement</a>
                <a href="glc.php">Gérer les capteurs</a>
                <a href="notification.php">Notifications</a>
                <a href="forum.php">Forum</a>
                <a href="parametre.php">Paramètres</a>
            </li>
        </nav>

    </header>

    <div class="container-titre-profil">
        <h1 class="titre_parametre"> Mon Profil </h1>
        <div class="barre-de-séparation"></div>
        <br>
        <h2 align="center"><?php echo ucwords($_SESSION['username']);?></h2>
        <br>

        <!--<button class="btn_recherche" >Recherche <i class="fas fa-search"></i></button>
        <br><br>-->
        <div class="monprofil_photo">
            <h2>Photo</h2>
        </div><br><br>

        <div align="center" class="monprofil_Score">
            <h2>Mon Score :</h2>

            <p class="colorscore">
                <?php echo $_SESSION['score'];?>
            </p>
            <br>
        </div>

        <br><br>
        <br><br>

        <button class="btn_deco" onClick="document.location.href='logout.php'">Deconexion</button>
    </div>
    
    <div class="monprofil_body1">
        <h2 class="title">Dangers <i class="fas fa-exclamation"></i></h2>
        <br><br>
        <li><b>  Attention <i class="fas fa-exclamation-triangle"></i>   :   </b>   Le niveau de CO2 dans la cuisine a atteint un seuil critique ! Vous devriez aérer pour renouveler l'air de la pièce ! </li>
        <br><br>
        <li><b>  Attention <i class="fas fa-exclamation-triangle"></i>   :   </b>  La température de la cuisine a atteint plus de 30°C ! Veuillez ouvrir les fenêtres afin d'aérer !</li>
        <br><br>
        <li><b>  Attention <i class="fas fa-exclamation-triangle"></i>   :   </b>  La température de la pièce a atteint moins de 18°C ! Veuillez fermer les fenêtres !</li>
        <br><br><br>
    </div>
    <div class="bgcolor"></div>


</body>

</html>