<?php
?>

<!DOCTYPE html>

<html lang="fr">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-Fo3rlrZj/k7ujTnHg4CGR2D7kSs0v4LLanw2qksYuRlEzO+tcaEPQogQ0KaoGN26/zrn20ImR1DfuLWnOo7aBA==" crossorigin="anonymous" referrerpolicy="no-referrer" /> 
    <script src="event.js"></script>   
    <title>Ecohome</title>
</head>

<style>
    
</style>

<body>

    <script src="event.js"></script>

    <header>
        <div id="top" class="top">
            <a href="#" class="logo"><img src="https://i.goopics.net/kdv184.png" class="ecohome"></a>
            <div class="profil">
                <a href="connexion.php">Se connecter</a>
                <a href="connexion.php"><img src="https://i.goopics.net/p5sdhc.png" class="profil_picture"></a>
            </div>
        </div>
    
        <nav>
            <li id="underhead" class="underhead">
                <a href="login.php">Accueil</a>
                <a href="connection_needed.php">Classement</a>
                <a href="connection_needed.php">Gérer les capteurs</a>
                <a href="connection_needed.php">Notifications</a>
                <a href="connection_needed.php">Forum</a>
                <a href="connection_needed.php">Paramètres</a>
            </li>
        </nav>

    </header>

    <div class="box_catchy">
        <label class="txt_catchy">Déjà plus de 10000 utilisateurs !</label>
    </div>

    <figure id="figure">
        <img src="https://i.goopics.net/jm2h5l.jpg" height="100%" width="100%" alt>
        <img src="https://i.goopics.net/agh491.png" height="80vh" width="100vh" alt>
        <img src="https://i.goopics.net/qv470s.jpg" height="80vh" width="100vh" alt>
        <img src="https://i.goopics.net/tljclu.jpg" height="80vh" width="100vh" alt>
        <img src="https://i.goopics.net/jm2h5l.jpg" height="80vh" width="100vh" alt>
    </figure>

</body>



</html>