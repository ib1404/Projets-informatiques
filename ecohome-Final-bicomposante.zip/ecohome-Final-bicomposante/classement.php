<?php
session_start();
$con = mysqli_connect("localhost","root","","config2");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="style.css" media="all" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <!-- lien de la blibliotèque d'icon fontawesome -->
    <title>Ecohome</title>


</head>

<body onload="afficher_classement_hebdomadaire()">

    <script src="event.js"></script>

    <header>
        <div id="top" class="top">
            <a href="index.php" class="logo"><img src="https://i.goopics.net/kdv184.png" class="ecohome"></a>
            <div class="profil">
                <a href="profil.php"><?php echo ucwords($_SESSION['username']); ?></a>
                <a href="profil.php"><img src="https://i.goopics.net/p5sdhc.png" class="profil_picture"></a>
                <!--<li> <div class="notification">
                    <a class="notification-number" href="">3</a>
                    <svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bell">
                    <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0" />
                    </svg>
                </div></li>-->
            </div>
        </div>
    
        <nav>
            <li id="underhead" class="underhead">
                <a href="index.php">Accueil</a>
                <a href="classement.php" style="color:#00FF00;">Classement</a>
                <a href="glc.php">Gérer les capteurs</a>
                <a href="notification.php">Notifications</a>
                <a href="forum.php">Forum</a>
                <a href="parametre.php">Paramètres</a>
            </li>
        </nav>

    </header>
<section data-section="1" >
    <div class="container-titre-param">

<h1 class="titre_parametre"> Classement </h1>

<div class="barre-de-séparation"></div>

</br>
</br>
<button class="btn_mon_compte"  onclick="afficher_classement_hebdomadaire()">classement hebdomadaire</button>


</br>
</br>

<button class="btn_mon_compte"  onclick="afficher_classement_mensuel()">classement mensuel</button>
<br>    
<br>


<button class="btn_mon_compte"><i class="fas fa-search"></i> <a href="recherche_utilisateur.php">Recherche un utilisateur </a> </button>
<br>
<br>
<button class="btn_mon_compte">  <a href="resetscore.php">  Reset Score </a></button>
   

</div>
</div>
<div class="container_classement" >    
    <div class="container_classement_1" id="pagecl1">
            <h1 >Classement de la semaine </h1>
            <table class="sticky">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nom</th>
                        <th>Ville</th>
                        <th>SCORE ECO</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                        
                        $classement1 = "SELECT * FROM `score` NATURAL JOIN `users` ORDER BY score DESC LIMIT 10;";
                        $result1 = mysqli_query($con, $classement1)  or mysqli_error();
                        $x = 1 ;
                        $classement2 = "SELECT * FROM `adresses` JOIN `score` ON adresses.id=score.id ORDER BY score DESC LIMIT 10;";
                        $result2 = mysqli_query($con, $classement2) or mysqli_error();
                
                        $row2=mysqli_fetch_assoc($result2);
                        while($row=mysqli_fetch_assoc($result1)){
                            ?>

                            <tr>    
                                <td> <?php echo "$x "; $x++; ?> </td>
                                <td> <?php echo "{$row['name']}" ?> </td>
                                <td> <?php echo "{$row2['ville']}" ?> </td>
                                <td> <?php echo "{$row['score']}" ?> </td>
                            </tr>

                    <?php       
                        }
                    ?>
            </tbody>
        </table>

    
    </div>
    <div class="container_classement_2" id="pagecl2">
        <h1 >Classement de mensuel</h1>
        <table class="sticky">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nom</th>
                    <th>Ville</th>
                    <th>SCORE ECO</th>
                </tr>
            </thead>
            <tbody>
                    <?php
                        $classement1 = "SELECT * FROM `score` NATURAL JOIN `users` ORDER BY score DESC LIMIT 10;";
                        $result1 = mysqli_query($con, $classement1)  or mysqli_error();
                        $y = 1 ;
                        $classement2 = "SELECT * FROM `adresses` JOIN `score` ON adresses.id=score.id ORDER BY score DESC LIMIT 10;";
                        $result2 = mysqli_query($con, $classement2) or mysqli_error();

                        $row2=mysqli_fetch_assoc($result2);
                        while($row=mysqli_fetch_assoc($result1)){
                            ?>
                            <tr>
                                <td> <?php echo "$y "; $y++; ?></td>
                                <td> <?php echo "{$row['name']}" ?> </td>
                                <td> <?php echo " {$row2['ville']}" ?> </td>
                                <td> <?php echo "{$row['score']}" ?> </td>
                            </tr>

                    <?php       
                          }
                    ?>
                
                        
                    
                        
                    

                </tbody>
            </table>
        </div>
    
    <script src="event.js"></script>
</div>
    </section>

</body>

</html>